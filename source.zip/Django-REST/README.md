# Django-REST

GET  localhost:8000/api/buy-sell-stocks

POST localhost:8000/api/buy-sell-stocks

        {
            "company_name" : "Appolo",
            "trade_type" : "BUY",
            "quantity" : 10.00,
            "buy_price" : 1389.55
        }

GET localhost:8000/api/holding-details?company_name=Appolo