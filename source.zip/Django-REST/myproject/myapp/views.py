import decimal
from django.shortcuts import render
from django.db.models import Sum
from rest_framework.views import APIView
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework import status
from myapp.models import CompanyTransactions, CompanyHoldingDetails
from myapp.serializers import CompanyTransactionsSerializer,CompanyHoldingDetailsSerializer
from rest_framework.decorators import api_view
# Create your views here.




class BuySellStocks(APIView):
    permission_classes = [permissions.AllowAny]

    """This endpoint allows for creation of a CompanyTransactionsSerializer"""

    def get(self,request,*args,**kwargs):
        transactions = CompanyTransactions.objects.all()
        serializer = CompanyTransactionsSerializer(transactions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def post(self, request, *args, **kwargs):
        data = {
            "company_name" : request.data.get('company_name'),
            "trade_type" : request.data.get('trade_type'),
            "quantity" : request.data.get('quantity'),
            "buy_price" : request.data.get('buy_price'),
            "amount" : request.data.get('quantity') * request.data.get('buy_price'),
        }

        serializer = CompanyTransactionsSerializer(data=data)

        if request.data.get('trade_type') not in ['BUY','SELL']:
            return Response('enter trade_type as BUY or SELL', status=status.HTTP_400_BAD_REQUEST)


        if serializer.is_valid():
            serializer_obj = serializer.save()


            # changing holding values


            # total buy calculate
            total_buy_qty = CompanyTransactions.objects.filter(
                    company_name=request.data.get('company_name'),
                    trade_type = 'BUY'
                ).values("trade_type").annotate(capital=Sum("quantity",default=decimal.Decimal(0)))

            # total sell calculate
            total_sell_qty = CompanyTransactions.objects.filter(
                    company_name=request.data.get('company_name'),
                    trade_type = 'SELL'
                ).values("trade_type").annotate(capital=Sum("quantity",default=decimal.Decimal(0)))
            
            total_buy = float(total_buy_qty[0].get('capital',0) if total_buy_qty else 0)
            total_sell = float(total_sell_qty[0].get('capital',0) if total_sell_qty else 0)



            the_difference_column = float(total_sell - request.data.get('quantity'))
            serializer_obj.the_difference_column = the_difference_column


            # closing_qty calculate
            closing_qty = total_buy - total_sell


            
           
            try:
                obj = CompanyHoldingDetails.objects.get(
                    company_name__iexact=request.data.get('company_name')
                    )
               
                obj.total_buy=total_buy
                obj.total_sell= total_sell
                obj.closing_qty=closing_qty
                obj.closing_value= total_buy
                obj.avg_purchase_price = total_buy
                obj.save()
                
            except CompanyHoldingDetails.DoesNotExist:
                CompanyHoldingDetails.objects.create(
                        company_name=request.data.get('company_name'),
                        total_buy=total_buy,
                        total_sell= total_sell,
                        closing_qty=closing_qty,
                        closing_value= total_buy,
                        avg_purchase_price = total_buy,
                )

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





class HoldingDetails(APIView):
    permission_classes = [permissions.AllowAny]

    """This endpoint allows for creation of a CompanyHoldingDetailsSerializer"""

    def get(self,request,*args,**kwargs):
        company_name = self.request.GET.get('company_name',None)
        abc  =CompanyHoldingDetails.objects.all()
        print(abc)
        try:
            transactions = CompanyHoldingDetails.objects.get(company_name__iexact=company_name)
            serializer = CompanyHoldingDetailsSerializer(transactions)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except CompanyHoldingDetails.DoesNotExist:
            return Response('error', status=status.HTTP_400_BAD_REQUEST)
