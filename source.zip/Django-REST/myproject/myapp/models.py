from django.db import models

# Create your models here.


class CompanyTransactions(models.Model):
    BUY = 'BUY'
    SELL = 'SELL'
    SEMESTER_CHOICES = (
            (BUY, 'BUY'),
            (SELL, 'SELL'),
            )

    date = models.DateField(auto_now_add=True)
    company_name = models.CharField(max_length=20)
    trade_type  = models.CharField(max_length=20, choices=SEMESTER_CHOICES, default=BUY)
    quantity = models.DecimalField(max_digits=20, decimal_places=2)
    buy_price = models.DecimalField(max_digits=20, decimal_places=2)
    amount= models.DecimalField(max_digits=20, decimal_places=2,null=True,blank=True)

    the_difference_column = models.CharField(max_length=20,null=True,blank=True)
    lot_pending_qty = models.DecimalField(max_digits=20, decimal_places=2,null=True,blank=True)
    lot_value = models.DecimalField(max_digits=20, decimal_places=2,null=True,blank=True)
    
  
  
    def __str__(self):
        return self.company_name


class CompanyHoldingDetails(models.Model):
    company_name = models.CharField(max_length=20)
    total_buy  =models.DecimalField(max_digits=20, decimal_places=2)
    total_sell = models.DecimalField(max_digits=20, decimal_places=2)
    closing_qty = models.DecimalField(max_digits=20, decimal_places=2)
    closing_value = models.DecimalField(max_digits=20, decimal_places=2)
    avg_purchase_price = models.DecimalField(max_digits=20, decimal_places=2)

    def __str__(self):
        return self.company_name
