from django.urls import path
from myapp.views import BuySellStocks, HoldingDetails

urlpatterns = [
    
    path("buy-sell-stocks", BuySellStocks.as_view(),name="buy_Sell_Stock"),
    path("holding-details", HoldingDetails.as_view(),name="holding_Details"),
   
]