from rest_framework import serializers
from myapp.models import CompanyTransactions, CompanyHoldingDetails

class CompanyTransactionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyTransactions
        fields = "__all__"

class CompanyHoldingDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyHoldingDetails
        fields = "__all__"